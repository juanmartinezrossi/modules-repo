/* 
 * Copyright (c) 2012
 * This file is part of ALOE (http://flexnets.upc.edu/)
 * 
 * ALOE++ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ALOE++ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ALOE++.  If not, see <http://www.gnu.org/licenses/>.
 */

/* Functions that generate the test data fed into the DSP modules being developed */
#include <complex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "source.h"
#include "turbocoder.h"
#include "turbodecoder.h"
#include "permute.h"
#include "ctrl_ratematching.h"

#include "LTEturboCOD_functions.h"

// LTE Defines
#define SUBFRAMES 	10		// Number of LTE SUBFRAMES
#define NUMFRAMES	1		// Number of simulated frames

// OPERATION defines
#define MAXDATA		1024*64
/* TURBOCODE CONFIGURATION*/
#define TURBOCODERONLY			0
#define TURBO_RATE_MATCHING		1
#define MAXITER 1



ctrl_turbocoder_t ctrlTurboCoder;
ctrl_turbodecoder_t ctrlTurboDecoder;
ctrl_source_t ctrlSource;
ctrl_ratematching_t ctrlRateMatching;
ctrl_ratematching_t ctrlUnRateMatching;

// TEST data
const int numbits[SUBFRAMES] = {1872,2016,2016,2016,2016,1872,2016,2016,2016,2016};

/**
 * @brief Defines the function activity.
 * @param .
 *
 * @param lengths Save on n-th position the number of samples generated for the n-th interface
 * @return -1 if error, the number of output data if OK

 */

int turboTEST(){
	int i,j,k;
	int nbits, errcnt=0, a, b, err;
	float BER=0.0;

//	int mode=TURBOCODERONLY;
	int mode=TURBO_RATE_MATCHING;
	int iterations=0;

	ctrl_source_t ctrl_source[SUBFRAMES];
	ctrl_turbocoder_t ctrl_turboenc[SUBFRAMES];
	ctrl_turbodecoder_t ctrl_turbodec[SUBFRAMES];
	ctrl_ratematching_t ctrl_rm [SUBFRAMES];
	ctrl_ratematching_t ctrl_unrm [SUBFRAMES];

	int cblen=0;
	char odata[MAXDATA], edata[MAXDATA], rdata[MAXDATA], rmdata[MAXDATA];
	float demapped [MAXDATA], unrmdata[MAXDATA];


	

	for(i=0; i<SUBFRAMES*NUMFRAMES; i++){
		k=i%SUBFRAMES;

		nbits=numbits[k];
		cblen = getLTEcbsize ((nbits-12)/3);
		printf("nbits=%d, cblen=%d\n", nbits, cblen);

		/* SOURCE CONFIGURATION */
		ctrl_source[k].typesource = RANDOM;
		ctrl_source[k].datalength = cblen;

		/* TURBO ENCODER CONFIG. */
		ctrl_turboenc[k].type = PER_LTE;
		ctrl_turboenc[k].blocklen = cblen;

		/* RATE MATCHING CONFIG. */
		ctrl_rm[i].mode = CHAR_RM;
		ctrl_rm[i].insize = cblen*3+12;
		ctrl_rm[i].outsize = nbits;
		ctrl_rm[i].rvidx = 0;

		/* UNRATE MATCHING CONFIG. */
		ctrl_unrm[i].mode = FLOAT_UNRM;
		ctrl_unrm[i].insize = nbits;
		ctrl_unrm[i].outsize = cblen*3+12;
		ctrl_unrm[i].rvidx = 0;

		/* TURBO DECODER CONFIG. */
		ctrl_turbodec[i].Long_CodeBlock = cblen;
		ctrl_turbodec[i].Turbo_Dt = 10;
		ctrl_turbodec[i].Turbo_iteracions = MAXITER;
		ctrl_turbodec[i].haltMethod = HALT_METHOD_MIN;
		ctrl_turbodec[i].type = PER_LTE;


	}
	
//	for(i=0; i<SUBFRAMES*NUMFRAMES; i++){
		cblen = getLTEcbsize ((nbits-12)/3);
		printf("ctrl_source[0].datalength=%d\n", ctrl_source[0].datalength);
		source(&ctrl_source[0], odata);
		printf("Subframe = 0, odata: \n");
		for(i=0; i<ctrl_source[0].datalength; i++){
			printf("%x", (int)(odata[i]&0x01));
		}
		printf("\n");
//	}
		printf("ctrl_turboenc[0].blocklen=%d\n", ctrl_turboenc[0].blocklen);
		TurboCoder(odata, edata, &ctrl_turboenc[0]);

		printf("edata: ctrl_rm[0].insize=%d\n", ctrl_rm[0].insize);
		for(i=0; i<ctrl_rm[0].insize; i++){
			printf("%d", edata[i]);
		}
		printf("\n");

		if(mode == TURBOCODERONLY){
			for(k=0; k<(ctrl_turbodec[0].Long_CodeBlock)*3+12; k++){
		//		printf("k=%d, %3.3f\n", k, (float)edata[k]);
		//		printf("%x\n", edata[k] & 0xFF);
		//		unrmdata[k]=(1-(float)(edata[k])*2);
				if(edata[k])unrmdata[k]=1.0;
				else unrmdata[k]=0.0;
		//		unrmdata[k]=(float)(edata[k] & 0x01);
		//		printf("%3.6f\n", unrmdata[k]);
			}
		}
//////////////////////////////////////////////////	
		if(mode == TURBO_RATE_MATCHING){

		printf("..............\n");	
			// Rate Matching 
			printf("ctrl_rm[i].insize =%d, ctrl_rm[i].outsize=%d\n", ctrl_rm[0].insize, ctrl_rm[0].outsize);
			err = ratematching (edata, rmdata, &ctrl_rm[0]);
			if (err <=0){
				printf("ERROR: Rate Matching bad configuration, exiting\n");
				return (-1);
			}

			printf("rmdata: \n");
			for(i=0; i<ctrl_rm[0].outsize; i++){
				printf("%d", rmdata[i]);
			}
			printf("\n");

	//		printf("rmdata: ");
			for(i=0; i<ctrl_rm[0].outsize; i++){
//				if(rmdata[i]&0x01 == 1)demapped[i]=1.0;
//				if(rmdata[i]&0x01 == 0)demapped[i]=0.0;
				if(rmdata[i])demapped[i]=1.0;
				else demapped[i]=0.0;
	//			else demapped[i]=0.0;
			}

			printf("demapped: \n");
			for(i=0; i<ctrl_rm[0].outsize; i++){
				printf("%1.0f", demapped[i]);
			}
			printf("\n");


			// Unrate matching
			ctrl_unrm[0].mode = FLOAT_UNRM;
			printf("ctrl_unrm[i].insize =%d, ctrl_unrm[i].outsize=%d\n", ctrl_unrm[0].insize, ctrl_unrm[0].outsize);
			err = ratematching (demapped, unrmdata, &ctrl_unrm[0]);
			if (err <=0){
				printf("ERROR: Rate Matching bad configuration, exiting\n");
				return (-1);
			}
			printf("unrmdata: ctrl_unrm[0].outsize=%d\n", ctrl_unrm[0].outsize);
			for(i=0; i<ctrl_unrm[0].outsize; i++){
				printf("%1.0f", unrmdata[i]);
			}
			printf("\n");
			printf("..............\n");	
		}
//////////////////////////////////////////////////		

		printf("ctrl_turbodec[0].Long_CodeBlock=%d\n", ctrl_turbodec[0].Long_CodeBlock);
		iterations += TurboDecoder(unrmdata, rdata, &ctrl_turbodec[0]);
		printf("rdata: \n");
		for(i=0; i<ctrl_source[0].datalength; i++){
			printf("%x", (int)(rdata[i]&0x01));
		}
		printf("\n");
		for (i=0; i<ctrl_source[0].datalength; i++){
			a=(int)(odata[i]&0x01);
			b=(int)(rdata[i]&0x01);
			if(a ^ b)errcnt++;
		}
		printf("\n		errocnt=%d, BER=%3.6f\n\n", errcnt, ((float)errcnt)/((float)nbits));
}



/////////////////////////////////////////////
void printarray(char *title, void *datain, int datatype, int length){
	int i;
	char DatType[STRLEN];
	char *charIN;
	int *intIN;
	float *floatIN;

	if(datatype == TCBITS){
		strcpy(DatType, "BITS");
		charIN=datain;
	} 
	if(datatype == TCCHAR){
		strcpy(DatType, "CHAR");
		charIN=datain;
	}
	if(datatype == TCFLOAT){
		strcpy(DatType, "FLOAT");
		floatIN=datain;
	}
	printf("@      %s, Data Type = %s, Data length=%d\n", title, DatType, length);
	for(i=0; i<length; i++){
		if(datatype == TCBITS)printf("%d", charIN[i]&0x01);
		if(datatype == TCFLOAT)printf("%1.0f", floatIN[i]);
		if(datatype == TCCHAR)printf("%x", charIN[i]&0xFF);
	}
	printf("\n");
}


void bits2floats(char *in, float *out, int length){
	int k;

	for(k=0; k<length; k++){
				if(in[k])out[k]=1.0; 
				else out[k]=-1.0; 
	}
}
/*
	Returns the number of bits.
*/

int CHARS2BITS (char *input, char *output, int inputlength){
	int i, k; 
	char a;
	
	for(k=0; k<inputlength; k++){
		a=*(input+k);
		*(output+k*8+7)=a&0x01;
		a=a>>1;
		*(output+k*8+6)=a&0x01;
		a=a>>1;
		*(output+k*8+5)=a&0x01;
		a=a>>1;
		*(output+k*8+4)=a&0x01;
		a=a>>1;
		*(output+k*8+3)=a&0x01;
		a=a>>1;
		*(output+k*8+2)=a&0x01;
		a=a>>1;
		*(output+k*8+1)=a&0x01;
		a=a>>1;
		*(output+k*8)=a&0x01;
	}
	return(inputlength*8);	//Number of output bits
}

/*
	Returns the number of bits.
*/
int BITS2CHARS (char *input, char *output, int inputlength)
{
    int i, k;
		char a=0x00;
		inputlength=inputlength>>3;

  for (i=0; i<inputlength; i++){
			k=i*8;
			*(output+i) =    *(input+k)<<7 | *(input+k+1)<<6
									 | *(input+k+2)<<5 | *(input+k+3)<<4
									 | *(input+k+4)<<3 | *(input+k+5)<<2 
									 | *(input+k+6)<<1 | *(input+k+7);
//			printf("%x\n", (int)(*(output+i))&0xFF);
	}
	return(inputlength); //Number of output chars
}

void initDataSource(int sourcetype, int datalength){

	ctrlSource.typesource = sourcetype; //TC_ALLONES; //RANDOM;
	ctrlSource.datalength = datalength;

}

int runDataSource(char *data, int datalength){

	ctrlSource.datalength = datalength;
	source(&ctrlSource, data);
	return(ctrlSource.datalength);
}


float computeBERchars(int length, char *odata, char *rdata, int BERperiod){
	int i, j=0, k;
	int a, b, c;
	static int errcnt=0;
	static int TotalData=0;
	static int period=0;
	float BER = 0.0;

	printf("Inside computeBER(): length=%d\n", length);

	period++;
	for (i=0; i<length; i++){
		a=(int)(odata[i]&0xFF);
		b=(int)(rdata[i]&0xFF);
		c=a ^ b;
		if(c){
			for(k=0; k<8; k++){
				if(c&0x01 == 1)errcnt++;
				c=c>>1;
			}
			
//			printf("i=%d, a=%x, b=%x\n", i, a, b);
		}
		TotalData++;
		if(period == BERperiod){
			period = 0;
			BER = ((float)errcnt)/((float)TotalData);
			printf("Total Data = %d, num errors = %d, BER=%3.6f\n", 
											TotalData, errcnt, BER);
		}
	}

	return(BER);
}


float computeBERbits(int length, char *odata, char *rdata, int BERperiod){
	int i, j=0;
	int a, b;
	static int errcnt=0;
	static int TotalData=0;
	static int period=0;
	float BER = 0.0;

//	printf("Inside computeBER(): length=%d\n", length);
//	printarray("odata", odata, TCCHAR, length);
//	printarray("rdata", rdata, TCCHAR, length);


	period++;
	for (i=0; i<length; i++){
		a=(int)(odata[i]&0x01);
		b=(int)(rdata[i]&0x01);
		if(a ^ b){
			errcnt++;
//			printf("i=%d, a=%x, b=%x\n", i, a, b);
		}
		TotalData++;
		if(period == BERperiod){
			period = 0;
			BER = ((float)errcnt)/((float)TotalData);
			printf("Total Data = %d, num errors = %d, BER=%3.6f\n", 
											TotalData, errcnt, BER);
		}
	}

	return(BER);
}


void initLTETurboCoder(int codeblocklength){

		ctrlTurboCoder.type = PER_LTE;
		ctrlTurboCoder.blocklen = codeblocklength;
}


void runLTETurboCoder(char *in, char *out, int length){

		ctrlTurboCoder.blocklen=length;
		TurboCoder(in, out, &ctrlTurboCoder);
}


void initLTETurboDeCoder(int codeblocklength, int MaxIterations, int TurboDT, int HaltMethod){
	static int iterations=0;
	static int num_decoding_ops=0;

	ctrlTurboDecoder.Long_CodeBlock = codeblocklength;
	ctrlTurboDecoder.Turbo_iteracions = MaxIterations;
	ctrlTurboDecoder.Turbo_Dt = 10;
	ctrlTurboDecoder.haltMethod = HALT_METHOD_MIN;
	//ctrlTurboDecoder.halt = PER_LTE;
	ctrlTurboDecoder.type = PER_LTE;
}

void runLTETurboDeCoder(float *in, char *out, int codeblocklength, int halt){
	static int iterations=0;
	static int num_decoding_ops=0;

	ctrlTurboDecoder.Long_CodeBlock = codeblocklength;
	iterations += TurboDecoder(in, out, &ctrlTurboDecoder);
	num_decoding_ops++;

//	printf("Averaged Number of Iterations = %3.3f\n", (float)iterations/(float)num_decoding_ops);
	
}


int getCodeBlock_length(int nbits){
	return(getLTEcbsize ((nbits-12)/3));
}


// RATEMATCHING
void initRateMatching(int codeblocklength, int numoutbits){

	/* RATE MATCHING CONFIG. */
	ctrlRateMatching.mode = CHAR_RM;
	ctrlRateMatching.insize = codeblocklength*3+12;
	ctrlRateMatching.outsize = numoutbits;
	ctrlRateMatching.rvidx = 0;

}


int runRateMatching(char *in, char *out, int codeblocklength, int numoutbits){
	int err;

	ctrlRateMatching.insize = codeblocklength*3+12;
	ctrlRateMatching.outsize = numoutbits;

//	printf("runRateMatching(): insize=%d, outsize=%d\n", ctrlRateMatching.insize, ctrlRateMatching.outsize);

	err = ratematching (in, out, &ctrlRateMatching);
	if (err <=0){
		printf("ERROR: Rate Matching bad configuration, exiting\n");
		return (-1);
	}
	return(0);
}



// UNRATEMATCHING
void initUnRateMatching(int codeblocklength, int numoutbits){

	/* UNRATE MATCHING CONFIG. */
	ctrlUnRateMatching.mode = FLOAT_UNRM;
	ctrlUnRateMatching.insize = numoutbits;
	ctrlUnRateMatching.outsize = codeblocklength*3+12;
	ctrlUnRateMatching.rvidx = 0;

}


int runUnRateMatching(float *in, float *out, int codeblocklength, int numoutbits){
	int err;

	ctrlUnRateMatching.insize = numoutbits; 
	ctrlUnRateMatching.outsize = codeblocklength*3+12;

//	printf("runUnRateMatching(): insize=%d, outsize=%d\n", ctrlUnRateMatching.insize, ctrlUnRateMatching.outsize);

	err = ratematching (in, out, &ctrlUnRateMatching);
	if (err <=0){
		printf("ERROR: Un Rate Matching bad configuration, exiting\n");
		return (-1);
	}
	return(0);
}



float get_variance(float snr_db,float scale) {
	return sqrt(pow(10,-snr_db/10)*scale);
}

float aver_power(float *in, int length){
	int i;
	float aver_power=0.0;

	for(i=0; i<length; i++){
		aver_power += (*(in+i)*(*(in+i)));
	}
	aver_power=aver_power/(float)length;
	return(aver_power);
}

/**
 * @brief Defines the function activity.
 * @param .
 *
 * @param lengths Save on n-th position the number of samples generated for the n-th interface
 * @return -1 if error, the number of output data if OK

 */
float rand_gauss (void) {
  float v1,v2,s;

  do {
    v1 = 2.0 * ((float) rand()/RAND_MAX) - 1;
    v2 = 2.0 * ((float) rand()/RAND_MAX) - 1;

    s = v1*v1 + v2*v2;
  } while ( s >= 1.0 );

  if (s == 0.0)
    return 0.0;
  else
    return (v1*sqrt(-2.0 * log(s) / s));
}

void gen_noise(float *x, float variance, int len) {
	int i;
	for (i=0;i<len;i++) {
		x[i] = rand_gauss();
		x[i] *= variance;
	}
}

void calculateCodeBlockLengths(sframeBits_t *sframeBITS, int NofFFTs, int NofRB, int ModOrder){
	int i;
	int aux;
	
//	sframeBITS->CodeRate=0.5;

	sframeBITS->subframeType=0;
	sframeBITS->MAXsubframeBits[0]=NofFFTs*12*NofRB*ModOrder;			// Number of bits normal subframe (14 FFTs)
	sframeBITS->MAXsubframeBits[1]=(NofFFTs-1)*12*NofRB*ModOrder;	// Number of bits PSS subframe (13 FFTs)
	sframeBITS->MAXsubframeBits[2]=7*12*NofRB*ModOrder;						// Number of bits starting subframe (7 FFTs)
	
	for(i=0; i<3; i++){
		sframeBITS->bits2rcvSF[i]=(int)((float)sframeBITS->MAXsubframeBits[i]*sframeBITS->CodeRate);
		sframeBITS->codeblocklengthSF[i]=getCodeBlock_length(sframeBITS->bits2rcvSF[i]*3+12);
		sframeBITS->bits2rcvSF[i]=sframeBITS->codeblocklengthSF[i];
		sframeBITS->residualbits[i]=sframeBITS->codeblocklengthSF[i]-sframeBITS->bits2rcvSF[i];
/*		printf("   calculateCodeBlockLengths(): \n\tMAXsubframeBits[%d]=%d, \n\tcodeblocklengthSF=%d, \n\tbits2rcvSF=%d, \n\tresidualbits=%d\n", 
										i, sframeBITS->MAXsubframeBits[i], 
										sframeBITS->codeblocklengthSF[i], 
										sframeBITS->bits2rcvSF[i], 
										sframeBITS->residualbits[i]);
*/
	}
}





