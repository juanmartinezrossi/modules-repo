/* 
 * Copyright (c) 2012.
 * This file is part of ALOE (http://flexnets.upc.edu/)
 * 
 * ALOE++ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ALOE++ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ALOE++.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <complex.h>
#include <fftw3.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "typetools.h"
#include <phal_sw_api.h>
#include "skeleton.h"
#include "params.h"

#include "LTEturboCOD_interfaces.h"
#include "LTEturboCOD_functions.h"
#include "LTEturboCOD.h"

//ALOE Module Defined Parameters. Do not delete.
char mname[STR_LEN]="LTEturboCOD";
#define ENCODER_ONLY			1
#define DECODER_ONLY			2
#define ENCODER_RATE_MATCHING	3
#define DECODER_RATE_MATCHING	4
#define TEST_TURBO_ENC_DEC		5
#define TEST_ALL								6
#define TEST_ENCOD_DECOD				7		
//int opmode=TEST_TURBO_ENC_DEC;
int opmode=TEST_ENCOD_DECOD; 



// Module General variables
int ModOrder = 4; // NUmber of bits of MQAM symbol
int NofRB = 6; 		// Number of RBs: 6 (FFT 128)	
int NofFFTs = 14;	// Number of FFTs in a subframe

sframeBits_t sframeBITS;

int subframeType=0;				// 0: 14 FFTs, 1: 13 FFTs, 2: 7 FFTs
int MAXbitsSubframes[3];	// Holds the MAX number of bits of different subframes
int rcvbitsSubframe[3]={2000, 1800, 1000};	//Holds de expected bits to be coded.
int codeblocklength=0;		// Number of bits to the input of turbocoder. Not all values possible.
int residualbits;		// Number of bits to add to adjust received bits with codeblocklength for each subframe
float CodeRate=0.0;

int NumIterations=1;

// Buffers
char odata[INPUT_MAX_DATA], bitdata[INPUT_MAX_DATA], testdata[INPUT_MAX_DATA], edata[INPUT_MAX_DATA], rdata[INPUT_MAX_DATA], rmdata[INPUT_MAX_DATA];
float demapped [INPUT_MAX_DATA], unrmdata[INPUT_MAX_DATA], noise[INPUT_MAX_DATA];

int subframe_bits=0; 			// Number of bits for a subframe with 14 OFDM symbols of 72 carriers and QAM modulation.

/*
 * Function documentation
 *
 * @returns 0 on success, -1 on error
 */
int initialize() {
	int i;

//	printf("INITIALIZEoooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooP\n");
	/* GET CONTROL PARAMETERS*/
	param_get_int("opmode", &opmode);
	param_get_float("CodeRate", &(sframeBITS.CodeRate));

	/* CALCULATE INPUT DATA BLOCK LENGTH*/
	calculateCodeBlockLengths( &sframeBITS, NofFFTs, NofRB, ModOrder);

	/* INITIALIZE TURBO CODER-DECODER INTERNALS*/
	initDataSource(TC_BIT_RANDOM, codeblocklength);
	initLTETurboCoder(codeblocklength);
	initLTETurboDeCoder(codeblocklength, NumIterations, DT, HALT_METHOD_MIN_);	
	initRateMatching(codeblocklength, subframe_bits);
	initUnRateMatching(codeblocklength, subframe_bits);

	/* Print Module Init Parameters */
	strcpy(mname, GetObjectName());
/*	printf("O--------------------------------------------------------------------------------------------O\n");
	printf("O    SPECIFIC PARAMETERS SETUP: \033[1;34m%s\033[0m\n", mname);
	printf("O      Nof Inputs=%d, DataTypeIN=%s, Nof Outputs=%d, DataTypeOUT=%s\n", 
		       NOF_INPUT_ITF, IN_TYPE, NOF_OUTPUT_ITF, OUT_TYPE);
	printf("O      opmode=%d, CodeRate=%3.1f\n", opmode, sframeBITS.CodeRate);
	if(opmode==ENCODER_ONLY){
		printf("O      Expected nof input chars: %d (14FFTs), %d (13FFTs), %d (7FFTs)\n", 
								sframeBITS.bits2rcvSF[0]/8, sframeBITS.bits2rcvSF[1]/8, sframeBITS.bits2rcvSF[2]/8);
	}
	if(opmode==DECODER_ONLY){
		printf("O      Expected nof input floats: %d (14FFTs), %d (13FFTs), %d (7FFTs)\n", 
								sframeBITS.MAXsubframeBits[0], sframeBITS.MAXsubframeBits[1], sframeBITS.MAXsubframeBits[2]);
	}
	printf("O--------------------------------------------------------------------------------------------O\n");
*/

	printf("\033[1;37;42m\tO--------------------------------------------------------------------------------------------O\t\033[0m\n");
	printf("\033[1;37;42m\tO    SPECIFIC PARAMETERS SETUP: %s                                   	      	\t\033[0m\n", mname);
	printf("\033[1;37;42m\tO      Nof Inputs=%d, DataTypeIN=%s, Nof Outputs=%d, DataTypeOUT=%s                    \t\033[0m\n", 
		       NOF_INPUT_ITF, IN_TYPE, NOF_OUTPUT_ITF, OUT_TYPE);
	printf("\033[1;37;42m\tO      opmode=%d, CodeRate=%3.1f                                             		\t\033[0m\n", opmode, sframeBITS.CodeRate);
	if(opmode==ENCODER_ONLY){
		printf("\033[1;37;42m\tO      Expected nof input chars: %d (14FFTs), %d (13FFTs), %d (7FFTs)              	\t\033[0m\n", 
															sframeBITS.bits2rcvSF[0]/8, sframeBITS.bits2rcvSF[1]/8, sframeBITS.bits2rcvSF[2]/8);
	}
	if(opmode==DECODER_ONLY){
		printf("\033[1;37;42m\tO      Expected nof input floats: %d (14FFTs), %d (13FFTs), %d(7FFTs)            	\t\033[0m\n", sframeBITS.MAXsubframeBits[0], sframeBITS.MAXsubframeBits[1], sframeBITS.MAXsubframeBits[2]);
	}
	printf("\033[1;37;42m\tO--------------------------------------------------------------------------------------------O\t\033[0m\n");


	return 0;
}



/**
 * @brief Function documentation
 *
 * @param inp Input interface buffers. Data from other interfaces is stacked in the buffer.
 * Use in(ptr,idx) to access the address. To obtain the number of received samples use the function
 * int get_input_samples(int idx) where idx is the interface index.
 *
 * @param out Input interface buffers. Data to other interfaces must be stacked in the buffer.
 * Use out(ptr,idx) to access the address.
 *
 * @return On success, returns a non-negative number indicating the output
 * samples that should be transmitted through all output interface. To specify a different length
 * for certain interface, use the function set_output_samples(int idx, int len)
 * On error returns -1.
 *
 * @code
 * 	input_t *first_interface = inp;
	input_t *second_interface = in(inp,1);
	output_t *first_output_interface = out;
	output_t *second_output_interface = out(out,1);
 *
 */
int work(input_t *inp, output_t *out) {
	int i;
	int dec_rcv_samples, encod_rcv_samples, rcv_samples = get_input_samples(0); /** number of samples at itf 0 buffer */
	int snd_samples=0;
	int out_turbo_samples;
	int error=0;
	static int first=0;
	float gain=1.0, power_noise=0.0, power_signal=0.0, SNR=0.75;
	int RsfIdx=-1;
	int Rcodeblocklength=0;
	int Rresidualbits=0;
	static int Tslot=0;

 	input_t *in0 = inp;
	output_t *out0 = out;

	
//	int i,k;
	
	// Check if data received
	//if (rcv_samples == 0)return(0);

//opmode = TEST_ENCOD_DECOD;
//printf("opmode=%d\n", opmode);
	
	//turboTEST();

	if(opmode == TEST_TURBO_ENC_DEC){
		codeblocklength=getCodeBlock_length(subframe_bits);
		if(first==0)printf("TEST_TURBO_ENC_DEC: subframe_bits=%d, codeblocklength=%d\n", subframe_bits, codeblocklength);
		first=1;
		rcv_samples=runDataSource(odata, codeblocklength);
		printarray("odata", odata, TCBITS, rcv_samples);
		runLTETurboCoder(odata, edata, rcv_samples);
		out_turbo_samples=rcv_samples*3+12;
//		printarray("edata", edata, TCBITS, out_turbo_samples);
		bits2floats(edata, unrmdata, out_turbo_samples);
		power_signal=aver_power(unrmdata, out_turbo_samples);
		gen_noise(noise, 1.0, out_turbo_samples);

		// Calculate power generated noise
		power_noise=aver_power(noise, out_turbo_samples);
		// Correct noise level according expected SNR. SNR=Psignal/(Gain*Pnoise)
		gain=power_signal/(SNR*power_noise);
		gain=sqrt(gain);

		// Add Noise
		for(i=0; i<out_turbo_samples; i++){
			*(unrmdata+i)=*(unrmdata+i)+gain*(*(noise+i));
		}

		runLTETurboDeCoder(unrmdata, rmdata, codeblocklength, 0);
		printarray("rmdata", rmdata, TCBITS, rcv_samples);
		computeBERbits(rcv_samples, odata, rmdata, 100);
	}
	// TEST ALL//////////////////////////////////////////////
	if(opmode == TEST_ALL){
		subframe_bits=72*4*14;
		rcv_samples=subframe_bits;
		codeblocklength=getCodeBlock_length(rcv_samples);

//		codeblocklength=700;	
		rcv_samples=runDataSource(odata, codeblocklength);
		if(first==0)printf("TEST_ALL: subframe_bits=%d, codeblocklength=%d, rcv_samples=%d\n", subframe_bits, codeblocklength, rcv_samples);
		first=1;
		
//		printarray("odata", odata, TCBITS, rcv_samples);
		runLTETurboCoder(odata, edata, rcv_samples);
		out_turbo_samples=rcv_samples*3+12;
//		printarray("edata", edata, TCBITS, out_turbo_samples);
		error=runRateMatching(edata, rmdata, codeblocklength, subframe_bits);
		if(error == -1)return(-1);
//		printarray("rmdata", rmdata, TCBITS, subframe_bits);
		bits2floats(rmdata, demapped, subframe_bits);
		error=runUnRateMatching(demapped, unrmdata, codeblocklength, subframe_bits);
		if(error == -1)return(-1);

//		printarray("unrmdata", unrmdata, TCFLOAT, out_turbo_samples);
		runLTETurboDeCoder(unrmdata, rmdata, codeblocklength, 0);
//		printarray("rmdata", rmdata, TCBITS, rcv_samples);
		computeBERbits(rcv_samples, odata, rmdata, 100);
	}
/*	if(opmode == TEST_ALL){
		codeblocklength=getCodeBlock_length(subframe_bits);
		printf("subframe_bits=%d, codeblocklength=%d\n", subframe_bits, codeblocklength);
		rcv_samples=runDataSource(odata);
		printarray("odata", odata, TCBITS, rcv_samples);
		runLTETurboCoder(odata, edata, rcv_samples);
		out_turbo_samples=rcv_samples*3+12;
		printarray("edata", edata, TCBITS, out_turbo_samples);
		error=runRateMatching(edata, rmdata, codeblocklength, subframe_bits);
		if(error == -1)return(-1);
		printarray("rmdata", rmdata, TCBITS, subframe_bits);
		bits2floats(rmdata, demapped, subframe_bits);
		error=runUnRateMatching(demapped, unrmdata, codeblocklength, subframe_bits);
		if(error == -1)return(-1);
		printarray("unrmdata", unrmdata, TCFLOAT, out_turbo_samples);
		runLTETurboDeCoder(unrmdata, rmdata, codeblocklength, 0);
		printarray("rmdata", rmdata, TCBITS, rcv_samples);
		computeBER(rcv_samples, odata, rmdata, 100);
	}
*/
/* OK
	if(opmode == ENCODER_ONLY){
		RATE=1.0;
		subframe_bits=72*4*14;
		rcv_samples=(int)(subframe_bits*RATE);		//subframe_bits;
		rcv_samples=1544*3+10;
		if(first==0)printf("rcv_samples=%d\n", rcv_samples);
		codeblocklength=getCodeBlock_length(rcv_samples);

		rcv_samples=runDataSource(odata, codeblocklength);
		if(first==0)printf("TEST_ALL: subframe_bits=%d, codeblocklength=%d, rcv_samples=%d, RATE=%3.1f\n", 
										subframe_bits, codeblocklength, rcv_samples, RATE);
		first=1;
		
//		printarray("odata", odata, TCBITS, rcv_samples);
		runLTETurboCoder(odata, edata, codeblocklength); //AQUI
		out_turbo_samples=codeblocklength*3+12;
//		printarray("edata", edata, TCBITS, out_turbo_samples);
		error=runRateMatching(edata, rmdata, codeblocklength, subframe_bits);
		if(error == -1)return(-1);
//		printarray("rmdata", rmdata, TCBITS, subframe_bits);

		bits2floats(rmdata, demapped, subframe_bits);
		error=runUnRateMatching(demapped, unrmdata, codeblocklength, subframe_bits);
		if(error == -1)return(-1);

//		printarray("unrmdata", unrmdata, TCFLOAT, out_turbo_samples);
		runLTETurboDeCoder(unrmdata, rmdata, codeblocklength, 0);
//		printarray("rmdata", rmdata, TCBITS, rcv_samples);
		computeBER(codeblocklength, odata, rmdata, 100);
	}
*/



	if(opmode == TEST_ENCOD_DECOD){

//int rcv_bits_options[3];	// Holds the number of bits of different subframes
//int codeblocklength=0;		// Number of bits to the input of turbocoder. Not all values possible.
//int residualbits=0;				// Number of bits to add to adjust received bits with codeblocklength.


		//#subframe_bits=72*4*14;
		sframeBITS.subframeType=2;
		subframe_bits=sframeBITS.MAXsubframeBits[sframeBITS.subframeType];
//		rcv_samples=(int)(subframe_bits*RATE);		//subframe_bits;
		//#rcv_samples=3900;
		rcv_samples=sframeBITS.bits2rcvSF[sframeBITS.subframeType];


		if(first==0)printf("rcv_samples=%d\n", rcv_samples);
	//	rcv_samples =rcv_samples*3+12;	
		//#codeblocklength=getCodeBlock_length(rcv_samples*3+12);
		codeblocklength=sframeBITS.codeblocklengthSF[sframeBITS.subframeType];
		//#residualbits=codeblocklength-rcv_samples;
		residualbits=sframeBITS.residualbits[sframeBITS.subframeType];

		//#runDataSource(odata, codeblocklength);
		runDataSource(odata, rcv_samples);
		if(first==0)printf("TEST_ENCOD_DECOD: subframe_bits[%d]=%d, codeblocklength=%d, rcv_samples=%d, residualbits=%d\n", 
										subframeType, subframe_bits, codeblocklength, rcv_samples, residualbits);
		
		
		printarray("odata", odata, TCBITS, rcv_samples);
		runLTETurboCoder(odata, edata, codeblocklength); //AQUI
//		out_turbo_samples=codeblocklength*3+12;
//		printarray("edata", edata, TCBITS, out_turbo_samples);
		error=runRateMatching(edata, rmdata, codeblocklength, subframe_bits);
		if(error == -1)return(-1);
//		printarray("rmdata", rmdata, TCBITS, subframe_bits);

		if(first==0){
			for(i=0; i<3; i++){
				printf("   calculateCodeBlockLengths(): \n\tMAXsubframeBits[%d]=%d, \n\tcodeblocklengthSF=%d, \n\tbits2rcvSF=%d, \n\tresidualbits=%d\n", 
												i, sframeBITS.MAXsubframeBits[i], 
												sframeBITS.codeblocklengthSF[i], 
												sframeBITS.bits2rcvSF[i], 
												sframeBITS.residualbits[i]);
			}

		}


		dec_rcv_samples=sframeBITS.MAXsubframeBits[sframeBITS.subframeType];
		// Detect subframe type: 14FFTs, 13FFTs or 7FFTs
		for(i=0; i<3; i++){
			if(sframeBITS.MAXsubframeBits[i] == dec_rcv_samples)RsfIdx=i;
		}
		Rcodeblocklength=sframeBITS.codeblocklengthSF[RsfIdx];
		Rresidualbits=sframeBITS.residualbits[RsfIdx];

		//PRINTAR VALORS
		if(first==0)printf("RsfIdx=%d, dec_rcv_samples=%d, Rcodeblocklength=%d, Rresidualbits=%d\n", 
												RsfIdx, dec_rcv_samples, Rcodeblocklength, Rresidualbits);

		bits2floats(rmdata, demapped, dec_rcv_samples);
		error=runUnRateMatching(demapped, unrmdata, Rcodeblocklength, dec_rcv_samples);
		if(error == -1)return(-1);

//		printarray("unrmdata", unrmdata, TCFLOAT, out_turbo_samples);
		runLTETurboDeCoder(unrmdata, rmdata, Rcodeblocklength, 0);
		printarray("rmdata", rmdata, TCBITS, rcv_samples);
		computeBERbits(Rcodeblocklength-Rresidualbits, odata, rmdata, 100);
	}





	// Debugg purposes only----------------
//		sframeBITS.subframeType=0;
//		rcv_samples=sframeBITS.bits2rcvSF[sframeBITS.subframeType];
//		if(first==0)printf("rcv_samples=%d\n", rcv_samples);
//		dec_rcv_samples=sframeBITS.MAXsubframeBits[sframeBITS.subframeType];

//OK///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*		for(i=0; i<5000; i++)*(testdata+i)=*(odata+i);
		runDataSource(odata, 5000);
	//-------------------------------------------------

	if(opmode == ENCODER_ONLY){
		sframeBITS.subframeType=0;
		encod_rcv_samples=sframeBITS.bits2rcvSF[sframeBITS.subframeType];
		if(first==0)printf("encod_rcv_samples=%d\n", encod_rcv_samples);
	
//		printarray("odata", odata, TCBITS, 256);
		//TRANSMITTER
		// Check if received data length match with expected values.
		for(i=0; i<3; i++)if(sframeBITS.bits2rcvSF[i] == encod_rcv_samples)sframeBITS.subframeType=i;
		// Set working parameters
		subframe_bits=sframeBITS.MAXsubframeBits[sframeBITS.subframeType];
		codeblocklength=sframeBITS.codeblocklengthSF[sframeBITS.subframeType];
		residualbits=sframeBITS.residualbits[sframeBITS.subframeType];
		if(first==0)printf("ENCODER_ONLY: subframe_bits[%d]=%d, codeblocklength=%d, encod_rcv_samples=%d, residualbits=%d\n", 
										subframeType, subframe_bits, codeblocklength, encod_rcv_samples, residualbits);

		runLTETurboCoder(odata, edata, codeblocklength); 
		// RateMatching: 
		//		subframe_bits=Bits that will be transmitted according number of RBs and number of OFDM symbols in a subframe.
		//		codeblocklength=Coded bits according MCS value.
		error=runRateMatching(edata, rmdata, codeblocklength, subframe_bits);
		if(error == -1)return(-1);
		snd_samples=subframe_bits;
		for(i=0; i<subframe_bits; i++)*(out0+i)=*(rmdata+i);

	}

	if(opmode == DECODER_ONLY){

	//RECEIVER
		dec_rcv_samples=rcv_samples;
		if(dec_rcv_samples==0)return(0);
		for(i=0; i<dec_rcv_samples; i++)*(rmdata+i)=*(in0+i);
//		printarray("DECOD in0", rmdata, TCBITS, 256);
		
//		printf("dec_rcv_samples=%d\n", dec_rcv_samples);
		for(i=0; i<3; i++)if(sframeBITS.MAXsubframeBits[i] == dec_rcv_samples)RsfIdx=i;
		Rcodeblocklength=sframeBITS.codeblocklengthSF[RsfIdx];
		Rresidualbits=sframeBITS.residualbits[RsfIdx];
		if(first==0)printf("RsfIdx=%d, dec_rcv_samples=%d, Rcodeblocklength=%d, Rresidualbits=%d\n", 
												RsfIdx, dec_rcv_samples, Rcodeblocklength, Rresidualbits);
		bits2floats(rmdata, demapped, dec_rcv_samples);
		error=runUnRateMatching(demapped, unrmdata, Rcodeblocklength, dec_rcv_samples);
		if(error == -1)return(-1);
		runLTETurboDeCoder(unrmdata, rmdata, Rcodeblocklength, 0);
	
		computeBER(Rcodeblocklength-Rresidualbits,testdata, rmdata, 100);

	}
*/


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
//OK
/*		CHARS2BITS(odata, bitdata, 6000);
		for(i=0; i<6000; i++)*(testdata+i)=*(bitdata+i);
		runDataSource(odata, 6000);
*/	
	//-------------------------------------------------



	if(opmode == ENCODER_ONLY){
		if(Tslot%100==0)printf("Encod encod_rcv_samples=%d\n", encod_rcv_samples);
		encod_rcv_samples=rcv_samples;
		if(encod_rcv_samples==0)return(0);
		for(i=0; i<3; i++)if(sframeBITS.bits2rcvSF[i]/8 == encod_rcv_samples)RsfIdx=i;
		if(RsfIdx == -1){
			printf("TurboEncoder: Data length received = %d does not match any of expected ones\n", encod_rcv_samples);
			printf("TurboEncoder: Please, check received values according CodeRate parameter\n", encod_rcv_samples);
			exit(0);
		}
		for(i=0; i<encod_rcv_samples; i++)*(odata+i)=*(in0+i);
/*		sframeBITS.subframeType=0;
		encod_rcv_samples=sframeBITS.bits2rcvSF[sframeBITS.subframeType]/8;
*/
//		if(first==0)printf("encod_rcv_samples=%d\n", encod_rcv_samples);

//		printarray("odata", odata, TCCHAR, 4);
		encod_rcv_samples=CHARS2BITS(odata, bitdata, encod_rcv_samples);
//		if(first==0)printf("encod_rcv_samples=%d\n", encod_rcv_samples);
//		printarray("bitdata", bitdata, TCBITS, 128);
		//TRANSMITTER
		// Check if received data length match with expected values.
		for(i=0; i<3; i++)if(sframeBITS.bits2rcvSF[i] == encod_rcv_samples)sframeBITS.subframeType=i;
		// Set working parameters
		subframe_bits=sframeBITS.MAXsubframeBits[sframeBITS.subframeType];
		codeblocklength=sframeBITS.codeblocklengthSF[sframeBITS.subframeType];
		residualbits=sframeBITS.residualbits[sframeBITS.subframeType];
//		if(first==0)printf("ENCODER_ONLY: subframe_bits[%d]=%d, codeblocklength=%d, encod_rcv_samples=%d, residualbits=%d\n", 
//										subframeType, subframe_bits, codeblocklength, encod_rcv_samples, residualbits);

		// Encoder: Only valid codeblocklength works fine. Acording LTE specs.
/////////// runLTETurboCoder(bitdata, edata, codeblocklength);
		runLTETurboCoder(bitdata, edata, codeblocklength); 
		//OK runLTETurboCoder(odata, edata, codeblocklength); 
		// RateMatching: 
		//		subframe_bits=Bits that will be transmitted according number of RBs and number of OFDM symbols in a subframe.
		//		codeblocklength=Coded bits according MCS value.
		error=runRateMatching(edata, rmdata, codeblocklength, subframe_bits);
		if(error == -1)return(-1);
		snd_samples=subframe_bits;
		for(i=0; i<subframe_bits; i++)*(out0+i)=*(rmdata+i);
		if(Tslot%100==0)printf("Encod snd_samples=%d\n", snd_samples);
	}

	if(opmode == DECODER_ONLY){

	//RECEIVER
		dec_rcv_samples=rcv_samples;
		if(Tslot%100==0)printf("Encod dec_rcv_samples=%d\n", dec_rcv_samples);
//		if(Tslot < 3)printf("dec_rcv_samples=%d\n", dec_rcv_samples);
		if(dec_rcv_samples==0)return(0);
		for(i=0; i<dec_rcv_samples; i++)*(rmdata+i)=*(in0+i);
//		printarray("DECOD in0", rmdata, TCBITS, 256);
		
//		printf("dec_rcv_samples=%d\n", dec_rcv_samples);
		for(i=0; i<3; i++)if(sframeBITS.MAXsubframeBits[i] == dec_rcv_samples)RsfIdx=i;
		if(RsfIdx == -1){
			printf("TurboDecoder: Data length received = %d does not match any of expected ones\n", dec_rcv_samples);
			printf("TurboDecoder: Please, check received values according CodeRate parameter\n", dec_rcv_samples);
			exit(0);
		}
		Rcodeblocklength=sframeBITS.codeblocklengthSF[RsfIdx];
		Rresidualbits=sframeBITS.residualbits[RsfIdx];
//		if(Tslot==1)printf("RsfIdx=%d, dec_rcv_samples=%d, Rcodeblocklength=%d, Rresidualbits=%d\n", 
//												RsfIdx, dec_rcv_samples, Rcodeblocklength, Rresidualbits);
		bits2floats(rmdata, demapped, dec_rcv_samples);
		error=runUnRateMatching(demapped, unrmdata, Rcodeblocklength, dec_rcv_samples);
		if(error == -1)return(-1);
		runLTETurboDeCoder(unrmdata, rmdata, Rcodeblocklength, 0);

	//	if(Tslot%100==0)printf("DECODER");
	
//		printf("Before COmputeBER(): RsfIdx=%d, dec_rcv_samples=%d, Rcodeblocklength=%d, Rresidualbits=%d\n", 
//												RsfIdx, dec_rcv_samples, Rcodeblocklength, Rresidualbits);
//		printarray("rmdata", rmdata, TCBITS, Rcodeblocklength-Rresidualbits);
/*		computeBERbits(Rcodeblocklength-Rresidualbits,bitdata, rmdata, 100);
*/
		//OK computeBER(Rcodeblocklength-Rresidualbits,testdata, rmdata, 100);
//		printarray("rmdata", rmdata, TCBITS, 256);
		snd_samples=BITS2CHARS(rmdata, out0, Rcodeblocklength-Rresidualbits);
		if(Tslot%100==0)printf("Decod snd_samples=%d\n", snd_samples);
	}

first=1;
	Tslot++;
	// Indicate the number of samples at output 0 with return value
	return snd_samples;
}

/** @brief Deallocates resources created during initialize().
 * @return 0 on success -1 on error
 */
int stop() {
	return 0;
}


